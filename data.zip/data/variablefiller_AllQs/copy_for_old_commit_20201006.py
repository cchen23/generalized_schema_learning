import os
import shutil

shutil.copy('test_QDESSERT_double.p', 'test_QDessert_bought.p')
shutil.copy('test_QEMCEE_double.p', 'test_QEmcee.p')
shutil.copy('test_QSUBJECT.p', 'test_QSubject.p')
shutil.copy('test_QDRINK.p', 'test_QDrink_bought.p')
shutil.copy('test_QPOET.p', 'test_QPoet.p')
shutil.copy('test_QFRIEND.p', 'test_QFriend.p')
