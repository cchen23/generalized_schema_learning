import numpy as np
import pickle

def save_double(filename):
    with open(filename, 'rb') as f:
        X, y = pickle.load(f)

    with open('old' + filename, 'wb') as f:
        pickle.dump([X, y], f)

    X = np.concatenate([X, X], axis=0)
    y = np.concatenate([y, y], axis=0)
    print(X.shape, y.shape)
    with open(filename, 'wb') as f:
        pickle.dump([X, y], f)

save_double('test_QDESSERT.p')
save_double('test_QEMCEE.p')
